// next-sitemap.js

module.exports = {
    siteUrl: 'https://solradian.com',
    generateRobotsTxt: true, // (optional)
  };
  