// src/pages/api/create-token.ts

import type { NextApiRequest, NextApiResponse } from "next";
import { createTokenFromPlatform } from "../../services/solana";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ message: `Method ${req.method} Not Allowed` });
  }

  const { recipientPublicKey, tokenName, symbol, decimals, supply } = req.body;

  if (!recipientPublicKey || !tokenName || !symbol || decimals === undefined || !supply) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    const { mintAddress, transactionSig } = await createTokenFromPlatform({
      recipientPublicKey,
      tokenName,
      symbol,
      decimals,
      supply,
    });

    return res.status(200).json({ mintAddress, transactionSig });
  } catch (error: any) {
    console.error("Error in create-token handler:", error);
    return res.status(500).json({ message: error.message });
  }
}
