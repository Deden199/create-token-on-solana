// src/pages/api/upload-metadata.ts

import type { NextApiRequest, NextApiResponse } from "next";
import formidable from "formidable";
import fs from "fs";
import { uploadMetadata } from "../../services/solana";

// Nonaktifkan body parser bawaan Next.js karena kita menggunakan formidable
export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ message: `Method ${req.method} Not Allowed` });
  }

  const form = new formidable.IncomingForm();

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error("Error parsing form:", err);
      return res.status(500).json({ message: "Error parsing form data" });
    }

    try {
      const imageFile = files.imageFile as formidable.File;

      if (!imageFile) {
        return res.status(400).json({ message: "Image file is required" });
      }

      const { tokenName, symbol, description } = fields;

      if (!tokenName || !symbol || !description) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const metadataUri = await uploadMetadata({
        tokenName: tokenName as string,
        symbol: symbol as string,
        description: description as string,
        imageFile: fs.createReadStream(imageFile.filepath),
      });

      return res.status(200).json({ metadataUri });
    } catch (error: any) {
      console.error("Error in upload-metadata handler:", error);
      return res.status(500).json({ message: error.message });
    }
  });
}
