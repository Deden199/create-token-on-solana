// src/services/solana.ts

import {
    Connection,
    PublicKey,
    SystemProgram,
    Transaction,
    TransactionSignature,
    Keypair,
    LAMPORTS_PER_SOL,
  } from "@solana/web3.js";
  import {
    TOKEN_PROGRAM_ID,
    createInitializeMintInstruction,
    getAssociatedTokenAddress,
    createAssociatedTokenAccountInstruction,
    createMintToInstruction,
  } from "@solana/spl-token";
  import axios from "axios";
  import FormData from "form-data";
  import fs from 'fs';
  
  interface UploadMetadataProps {
    tokenName: string;
    symbol: string;
    description: string;
    imageFile: fs.ReadStream;
  }
  
  export async function uploadMetadata({
    tokenName,
    symbol,
    description,
    imageFile,
  }: UploadMetadataProps): Promise<string> {
    try {
      // Verifikasi environment variables
      console.log("PINATA_API_KEY:", process.env.PINATA_API_KEY);
      console.log("PINATA_SECRET_API_KEY:", process.env.PINATA_SECRET_API_KEY);
  
      if (
        !process.env.PINATA_API_KEY ||
        !process.env.PINATA_SECRET_API_KEY
      ) {
        throw new Error("Required environment variables are not set.");
      }
  
      console.log("Menginisialisasi koneksi ke Pinata...");
  
      const pinataApiKey = process.env.PINATA_API_KEY;
      const pinataSecretApiKey = process.env.PINATA_SECRET_API_KEY;
  
      // Unggah gambar ke Pinata
      const imageFormData = new FormData();
      imageFormData.append("file", imageFile);
  
      const imageResponse = await axios.post(
        "https://api.pinata.cloud/pinning/pinFileToIPFS",
        imageFormData,
        {
          headers: {
            ...imageFormData.getHeaders(),
            pinata_api_key: pinataApiKey,
            pinata_secret_api_key: pinataSecretApiKey,
          },
        }
      );
  
      console.log("Image Response:", imageResponse.data);
  
      const imageHash = imageResponse.data.IpfsHash;
      const imageUrl = `https://gateway.pinata.cloud/ipfs/${imageHash}`;
      console.log("Gambar berhasil diunggah ke Pinata:", imageUrl);
  
      // Unggah metadata ke Pinata
      const metadata = {
        name: tokenName,
        symbol: symbol,
        description: description,
        image: imageUrl,
      };
  
      const metadataResponse = await axios.post(
        "https://api.pinata.cloud/pinning/pinJSONToIPFS",
        metadata,
        {
          headers: {
            "Content-Type": "application/json",
            pinata_api_key: pinataApiKey,
            pinata_secret_api_key: pinataSecretApiKey,
          },
        }
      );
  
      console.log("Metadata Response:", metadataResponse.data);
  
      const metadataHash = metadataResponse.data.IpfsHash;
      const metadataUri = `https://gateway.pinata.cloud/ipfs/${metadataHash}`;
      console.log("Metadata berhasil diunggah ke Pinata:", metadataUri);
  
      return metadataUri;
    } catch (error: any) {
      console.error("Error di uploadMetadata:", error);
      throw new Error(error.message);
    }
  }
  
  export async function createTokenFromPlatform({
    recipientPublicKey,
    tokenName,
    symbol,
    decimals,
    supply,
  }: {
    recipientPublicKey: string;
    tokenName: string;
    symbol: string;
    decimals: number;
    supply: number;
  }): Promise<{
    mintAddress: string;
    transactionSig: string;
  }> {
    try {
      if (!process.env.PLATFORM_PRIVATE_KEY) {
        throw new Error("Platform private key is not set.");
      }
  
      // Konversi private key dari string ke Uint8Array
      const privateKeyString = process.env.PLATFORM_PRIVATE_KEY.replace(/[\[\]]/g, '');
      const privateKey = new Uint8Array(privateKeyString.split(',').map(Number));
  
      const platformKeypair = Keypair.fromSecretKey(privateKey);
      const connection = new Connection(process.env.NEXT_PUBLIC_SOLANA_RPC_URL as string, "confirmed");
  
      // Buat Mint Keypair
      const mintKeypair = Keypair.generate();
      const mintPublicKey = mintKeypair.publicKey;
  
      // Cari rent exemption
      const rentExemption = await connection.getMinimumBalanceForRentExemption(82);
  
      // Buat Mint Account dan Initialize Mint
      const createMintTx = new Transaction().add(
        SystemProgram.createAccount({
          fromPubkey: platformKeypair.publicKey,
          newAccountPubkey: mintPublicKey,
          space: 82,
          lamports: rentExemption,
          programId: TOKEN_PROGRAM_ID,
        }),
        createInitializeMintInstruction(
          mintPublicKey,
          decimals,
          platformKeypair.publicKey,
          platformKeypair.publicKey
        )
      );
  
      // Tandatangani transaksi
      createMintTx.feePayer = platformKeypair.publicKey;
      createMintTx.recentBlockhash = (await connection.getLatestBlockhash()).blockhash;
  
      const signedCreateMintTx = await platformKeypair.signTransaction(createMintTx);
      const createMintSignature = await connection.sendRawTransaction(
        signedCreateMintTx.serialize()
      );
      await connection.confirmTransaction(createMintSignature, "confirmed");
  
      console.log("Mint created:", createMintSignature);
  
      // Buat ATA (Associated Token Account) untuk penerima
      const ataPublicKey = await getAssociatedTokenAddress(new PublicKey(mintPublicKey), new PublicKey(recipientPublicKey));
  
      const createATAIx = createAssociatedTokenAccountInstruction(
        platformKeypair.publicKey,
        ataPublicKey,
        new PublicKey(recipientPublicKey),
        mintPublicKey
      );
  
      const createATATx = new Transaction().add(createATAIx);
      createATATx.feePayer = platformKeypair.publicKey;
      createATATx.recentBlockhash = (await connection.getLatestBlockhash()).blockhash;
  
      const signedCreateATATx = await platformKeypair.signTransaction(createATATx);
      const createATASignature = await connection.sendRawTransaction(
        signedCreateATATx.serialize()
      );
      await connection.confirmTransaction(createATASignature, "confirmed");
  
      console.log("ATA created:", createATASignature);
  
      // Mint tokens ke ATA
      const mintToIx = createMintToInstruction(
        mintPublicKey,
        ataPublicKey,
        platformKeypair.publicKey,
        supply * Math.pow(10, decimals)
      );
  
      const mintToTx = new Transaction().add(mintToIx);
      mintToTx.feePayer = platformKeypair.publicKey;
      mintToTx.recentBlockhash = (await connection.getLatestBlockhash()).blockhash;
  
      const signedMintToTx = await platformKeypair.signTransaction(mintToTx);
      const mintToSignature = await connection.sendRawTransaction(
        signedMintToTx.serialize()
      );
      await connection.confirmTransaction(mintToSignature, "confirmed");
  
      console.log("Tokens minted:", mintToSignature);
  
      return {
        mintAddress: mintPublicKey.toBase58(),
        transactionSig: mintToSignature,
      };
    } catch (error: any) {
      console.error("Error di createTokenFromPlatform:", error);
      throw new Error(error.message);
    }
  }
  