<<<<<<< HEAD
# create-token-on-solana
solradian.com
=======
Solradian - Simplest Solana SPL Token Creator
Project Overview
Solradian is the most affordable and easiest-to-use platform for creating SPL tokens on the Solana blockchain. With Solradian, you can:

Create SPL Tokens: No coding skills required; simply fill in the details, and you're ready to go.
Direct Pool Integration: Add tokens directly to liquidity pools without unnecessary features.
Low Fees: The most cost-efficient solution for token creation.
Fast Transactions: Experience the speed and scalability of the Solana blockchain.
Visit Solradian.com to learn more about how we simplify token creation.
>>>>>>> 58d09ad (Initial commit: Add create-token-on-solana project)
